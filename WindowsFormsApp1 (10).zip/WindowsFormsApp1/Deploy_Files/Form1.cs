﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Deploy_Files
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            textBox5_TextChanged(textBox5, new System.EventArgs());

            List<string> data = File.ReadLines(Application.ExecutablePath + @".ini").Skip(19).Take(7).ToList();
            var ips = data[3].Split(Convert.ToChar(","));
            foreach (var item in ips)
            {
                if (item != string.Empty) checkedListBox2.Items.Add(item);
            }

            textBox2.Text = data[4];
            textBox3.Text = data[5];
            textBox4.Text = data[0];
            textBox6.Text = data[1];
        }

        public List<dynamic> fullFiles = new List<dynamic>();
        public List<dynamic> safeFiles = new List<dynamic>();

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            dateTimePicker1.Value = dateTimePicker2.Value.AddHours(Convert.ToDouble(textBox5.Text));
        }


        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            fullFiles.AddRange(openFileDialog1.FileNames);
            safeFiles.AddRange(openFileDialog1.SafeFileNames);
            foreach (var item in safeFiles)
            {
                checkedListBox1.Items.Add(item);
            }
            Console.WriteLine("nice");
        }

        private void button2_Click(object sender, EventArgs e)
        {

            Console.WriteLine("nice");
        }
    }
}
