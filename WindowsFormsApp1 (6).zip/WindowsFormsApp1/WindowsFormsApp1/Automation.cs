using NCM_Downloader;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Runtime.InteropServices;
using System.Security;
using System.Text;
using System.Windows.Controls;
using System.Windows.Forms;

namespace SimulateKeyPress
{
    class Form1 : Form
    {
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox2;
        private Form frm1 = new Form();

        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.Run(new Form1());
            //Done by Muresan Radu-Adrian MURA02 20200716
        }

        public Form1()
        {
            InitializeComponent();

            string configPath = Application.ExecutablePath + ".ini";
            if (File.Exists(configPath))
            {
                var configFile = File.ReadLines(configPath);

                textBox2.Text = configFile.ElementAt(0);
                textBox1.Text = configFile.ElementAt(1);
                textBox4.Text = configFile.ElementAt(2);
            }

            textBox4_TextChanged(textBox4, new System.EventArgs());

            button1.Click += new EventHandler(Button1_Click);

            this.DoubleClick += new EventHandler(Form1_DoubleClick);
            this.Controls.Add(button1);
            this.Controls.Add(textBox1);
        }

        // Get a handle to an application window.
        [DllImport("USER32.DLL", CharSet = CharSet.Unicode)]
        public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        //get objects in window ?
        [DllImport("user32.dll")]
        public static extern IntPtr FindWindowEx(IntPtr handleParent, IntPtr handleChild, string className, string WindowName);

        // Activate an application window.
        [DllImport("USER32.DLL")]
        public static extern bool SetForegroundWindow(IntPtr hWnd);
        internal delegate int WindowEnumProc(IntPtr hwnd, IntPtr lparam);

        [DllImport("user32.dll")]
        static extern IntPtr SendMessage(IntPtr hWnd, int Msg, int wParam, IntPtr lParam);

        private const int BM_CLICK = 0x00F5;

        [System.Runtime.InteropServices.DllImport("user32.dll", EntryPoint = "SendMessage", CharSet = System.Runtime.InteropServices.CharSet.Auto)]
        public static extern bool SendMessage(IntPtr hWnd, uint Msg, int wParam, StringBuilder lParam);

        [System.Runtime.InteropServices.DllImport("user32.dll", SetLastError = true)]
        public static extern IntPtr SendMessage(int hWnd, int Msg, int wparam, int lparam);

        const int WM_GETTEXT = 0x000D;
        const int WM_GETTEXTLENGTH = 0x000E;
        const int MY_MAXLVITEMTEXT = 260;

        public string GetControlText(IntPtr hWnd)
        {

            // Get the size of the string required to hold the window title (including trailing null.) 
            Int32 titleSize = SendMessage((int)hWnd, WM_GETTEXTLENGTH, 0, 0).ToInt32();

            // If titleSize is 0, there is no title so return an empty string (or null)
            if (titleSize == 0)
                return String.Empty;

            StringBuilder title = new StringBuilder(titleSize + 1);

            SendMessage(hWnd, (int)WM_GETTEXT, title.Capacity, title);

            return title.ToString();
        }

        ////this is for GetTreeItemText.....
        //[Flags]
        //public enum ProcessAccessFlags : uint
        //{
        //    All = 0x001F0FFF,
        //    Terminate = 0x00000001,
        //    CreateThread = 0x00000002,
        //    VirtualMemoryOperation = 0x00000008,
        //    VirtualMemoryRead = 0x00000010,
        //    VirtualMemoryWrite = 0x00000020,
        //    DuplicateHandle = 0x00000040,
        //    CreateProcess = 0x000000080,
        //    SetQuota = 0x00000100,
        //    SetInformation = 0x00000200,
        //    QueryInformation = 0x00000400,
        //    QueryLimitedInformation = 0x00001000,
        //    Synchronize = 0x00100000
        //}
        //public enum AllocationType
        //{
        //    Commit = 0x1000,
        //    Reserve = 0x2000,
        //    Decommit = 0x4000,
        //    Release = 0x8000,
        //    Reset = 0x80000,
        //    Physical = 0x400000,
        //    TopDown = 0x100000,
        //    WriteWatch = 0x200000,
        //    LargePages = 0x20000000
        //}

        //[DllImport("user32.dll", SetLastError = true)]
        //static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

        //[DllImport("kernel32.dll", SetLastError = true)]
        //public static extern IntPtr OpenProcess(ProcessAccessFlags processAccess, bool bInheritHandle, int processId);
        //public static IntPtr OpenProcess(Process proc, ProcessAccessFlags flags) { return OpenProcess(flags, false, proc.Id); }

        //[DllImport("kernel32.dll", SetLastError = true)]
        //[ReliabilityContract(Consistency.WillNotCorruptState, Cer.Success)]
        //[SuppressUnmanagedCodeSecurity]
        //[return: MarshalAs(UnmanagedType.Bool)]
        //static extern bool CloseHandle(IntPtr hObject);

        //[DllImport("user32")]
        //public static extern bool IsWindowUnicode(IntPtr hwnd);

        //[DllImport("kernel32.dll", SetLastError = true, ExactSpelling = true)]
        //static extern bool VirtualFreeEx(IntPtr hProcess, IntPtr lpAddress, int dwSize, AllocationType dwFreeType);

        //[DllImport("kernel32.dll", SetLastError = true, ExactSpelling = true)]
        //public static unsafe extern bool VirtualFreeEx(IntPtr hProcess, byte* pAddress, int size, AllocationType freeType);

        //public static string GetTreeItemText(IntPtr treeViewHwnd, IntPtr hItem)
        //{
        //    string itemText;

        //    uint pid;
        //    GetWindowThreadProcessId(treeViewHwnd, out pid);

        //    IntPtr process = OpenProcess(ProcessAccessFlags.VirtualMemoryOperation | ProcessAccessFlags.VirtualMemoryRead | ProcessAccessFlags.VirtualMemoryWrite | ProcessAccessFlags.QueryInformation, false, pid);
        //    if (process == IntPtr.Zero)
        //        throw new Exception("Could not open handle to owning process of TreeView", new Win32Exception());

        //    try
        //    {
        //        uint tviSize = Marshal.SizeOf(typeof(TabItem));

        //        uint textSize = MY_MAXLVITEMTEXT;
        //        bool isUnicode = IsWindowUnicode(treeViewHwnd);
        //        if (isUnicode)
        //            textSize *= 2;

        //        IntPtr tviPtr = VirtualAllocEx(process, IntPtr.Zero, tviSize + textSize, AllocationType.Commit, MemoryProtection.ReadWrite);
        //        if (tviPtr == IntPtr.Zero)
        //            throw new Exception("Could not allocate memory in owning process of TreeView", new Win32Exception());

        //        try
        //        {
        //            IntPtr textPtr = IntPtr.Add(tviPtr, tviSize);

        //            TVITEM tvi = new TVITEM();
        //            tvi.mask = TVIF_TEXT;
        //            tvi.hItem = hItem;
        //            tvi.cchTextMax = MY_MAXLVITEMTEXT;
        //            tvi.pszText = textPtr;

        //            IntPtr ptr = Marshal.AllocHGlobal(tviSize);
        //            try
        //            {
        //                Marshal.StructureToPtr(tvi, ptr, false);
        //                if (!WriteProcessMemory(process, tviPtr, ptr, tviSize, IntPtr.Zero))
        //                    throw new Exception("Could not write to memory in owning process of TreeView", new Win32Exception());
        //            }
        //            finally
        //            {
        //                Marshal.FreeHGlobal(ptr);
        //            }

        //            if (SendMessage(treeViewHwnd, isUnicode ? TVM_GETITEMW : TVM_GETITEMA, 0, tviPtr) != 1)
        //                throw new Exception("Could not get item data from TreeView");

        //            ptr = Marshal.AllocHGlobal(textSize);
        //            try
        //            {
        //                int bytesRead;
        //                if (!ReadProcessMemory(process, textPtr, ptr, textSize, out bytesRead))
        //                    throw new Exception("Could not read from memory in owning process of TreeView", new Win32Exception());

        //                if (isUnicode)
        //                    itemText = Marshal.PtrToStringUni(ptr, bytesRead / 2);
        //                else
        //                    itemText = Marshal.PtrToStringAnsi(ptr, bytesRead);
        //            }
        //            finally
        //            {
        //                Marshal.FreeHGlobal(ptr);
        //            }
        //        }
        //        finally
        //        {
        //            VirtualFreeEx(process, tviPtr, 0, FreeType.Release);
        //        }
        //    }
        //    finally
        //    {
        //        CloseHandle(process);
        //    }

        //    //char[] arr = itemText.ToCharArray(); //<== use this array to look at the bytes in debug mode

        //    return itemText;
        //}

        public List<string> ExtractWindowTextByHandle(IntPtr handle)
        {
            List<System.IntPtr> childObjects = new List<System.IntPtr>();
            var extractedText = new List<string>();
            childObjects = new WindowHandleInfo(handle).GetAllChildHandles();
            for (int i = 0; i < childObjects.Count; i++)
            {
                extractedText.Add(GetControlText(childObjects[i]));
            }
            return extractedText;
        }

        public List<string> ExtractTextByProcessName(string handle)
        {
            List<System.IntPtr> childObjects = new List<System.IntPtr>();
            var extractedText = new List<string>();
            Process[] anotherApps = Process.GetProcessesByName("s7tgtopx");
            if (anotherApps.Length > 0)
            {
                if (anotherApps[0] != null)
                {
                    childObjects = new WindowHandleInfo(anotherApps[0].MainWindowHandle).GetAllChildHandles();
                    for (int i = 0; i < childObjects.Count; i++)
                    {
                        extractedText.Add(GetControlText(childObjects[i]));
                    }
                }
            }
            return extractedText;
        }

        private void SleepUntilDownloadFeedback(int clientIndex)
        {
            bool finished = false;
            bool copied = false;
            DateTime copiedTime = DateTime.Now;
            DateTime comparTime = copiedTime;

            var filePath = textBox2.Text + "(" + clientIndex + ")\\winccom\\LOAD.LOG";

            System.Threading.Thread.Sleep(30000);

            while (finished == false)
            {
                if (File.Exists(filePath))
                {
                    System.IO.FileStream fs = new System.IO.FileStream(filePath, System.IO.FileMode.Open, System.IO.FileAccess.Read, System.IO.FileShare.ReadWrite);
                    System.IO.StreamReader sr = new System.IO.StreamReader(fs);
                    List<String> lst = new List<string>();

                    while (!sr.EndOfStream)
                        lst.Add(sr.ReadLine());

                    var lastLine = lst.Last(); //File.ReadLines(filePath).Last();
                    finished = lastLine.Contains("The lock on the project was removed"); //now can click ok to conclude download and onto next

                    //safety wait for 40 seconds after the files have been copied, then check is finished...
                    if (lastLine.Contains("The files were copied successfully") && copiedTime == comparTime)
                    {
                        copied = true;
                        copiedTime = DateTime.Now;
                    }
                    if (lastLine.Contains("The computer name was changed in the project") && copied == true)
                    {
                        int diffInSeconds = (DateTime.Now - copiedTime).Seconds;
                        if (finished == false && diffInSeconds > 40)
                        {
                            finished = true;
                        }
                    }
                }
                System.Threading.Thread.Sleep(500);
            }
        }

        private void CheckInputs()
        {
            if (textBox1.Text == null || textBox1.Text == "")
            {
                MessageBox.Show(new Form { TopMost = true }, "Please input the index at which clients start");
                return;
            }
            if (textBox2.Text == null || textBox2.Text == "")
            {
                MessageBox.Show(new Form { TopMost = true }, " Please input the path in the following form: " + @"D:\Project\SDIB_TCM\wincproj\SDIB_TCM_CLT_Ref");
                return;
            }
            if (textBox4.Text == null || textBox4.Text == "")
            {
                MessageBox.Show(new Form { TopMost = true }, " Please input the number of clients");
                return;
            }
            if (checkedListBox1.CheckedItems.Count == 0)
            {
                MessageBox.Show(new Form { TopMost = true }, " You have not checked any clients to download to!");
                return;
            }
        }

        // Send a series of key presses to the application.
        private void Button1_Click(object sender, EventArgs e)
        {
            //
            // check inputs
            //
            CheckInputs();
            //
            //write config file
            //
            string configPath = Application.ExecutablePath + ".ini";
            var configFile = File.CreateText(configPath);
            configFile.WriteLine(textBox2.Text);
            configFile.WriteLine(textBox1.Text);
            configFile.WriteLine(textBox4.Text);
            configFile.Close();
            // init logFile
            string logPath = Application.StartupPath + "\\NCM_Downloader.logger";
            var logFile = File.CreateText(logPath);
            //
            // initialize handles for windows
            //
            var ncmWndClass = "s7tgtopx"; //ncm manager main window
            var tgtWndClass = "#32770"; //usually any popup

            IntPtr ncmHandle = FindWindow(ncmWndClass, null);
            IntPtr tgtWndHandle = FindWindow(tgtWndClass, null);

            if (ncmHandle == IntPtr.Zero)
            {
                MessageBox.Show(new Form { TopMost = true }, " Simatic NCM Manager is not running.");
                return;
            }

            //handle the missing software package notification
            if (tgtWndHandle != IntPtr.Zero)
            {
                IntPtr btnHandle = FindWindowEx(tgtWndHandle, IntPtr.Zero, "Button", null);

                if (btnHandle != new IntPtr(0x00000000))
                {
                    SetForegroundWindow(tgtWndHandle);
                    SendMessage(btnHandle, BM_CLICK, (int)IntPtr.Zero, IntPtr.Zero);
                    SetForegroundWindow(ncmHandle);
                }
            }
            else
            {
                //Console.WriteLine("The missing software package notification did not appear");
                SetForegroundWindow(ncmHandle);
            }

            if (tgtWndHandle != IntPtr.Zero)
            {
                // sys tree view 32 already selected when focusing - navigate from here
                SetForegroundWindow(ncmHandle);


                //now perform actions from now on, i.e. CTRL+L
                for (int i = 0; i < checkedListBox1.CheckedItems.Count; i++)
                {
                    var clientIndex = checkedListBox1.CheckedIndices[i];
                    //download process starts here - first needs to navigate to correct index
                    ResetExpansions();
                    ReturnToFirstClient();
                    DownloadToCurrentIndex(clientIndex);

                    logFile.WriteLine("Attempting download to client index " + checkedListBox1.CheckedIndices[i] + 1);

                    //now new window with download os
                    IntPtr osDldTgtWndHandle = FindWindow(tgtWndClass, "Download OS");
                    if (osDldTgtWndHandle != IntPtr.Zero)
                    {
                        IntPtr DlButtonHandle = FindWindowEx(osDldTgtWndHandle, IntPtr.Zero, "Button", null);
                        if (DlButtonHandle != new IntPtr(0x00000000))
                        {
                            System.Threading.Thread.Sleep(500); //important to wait a bit
                            SendKeys.SendWait("{ENTER}"); //close runtime? focus is on yes
                            System.Threading.Thread.Sleep(500);
                            SetForegroundWindow(osDldTgtWndHandle);
                            SendKeys.Send("{ENTER}");

                            //if Canceled by the user in LOAD.LOG , assume that RT station not obtainable //read load.log here to find canceled by user
                            var downloadTargetWindowText = ExtractWindowTextByHandle(osDldTgtWndHandle);

                            if (downloadTargetWindowText.Where(x => x.Contains("Error")).Count() > 0)
                            {
                                System.Threading.Thread.Sleep(500);
                                SetForegroundWindow(osDldTgtWndHandle);
                                System.Threading.Thread.Sleep(200);
                                SendKeys.Send("{ENTER}");
                                logFile.WriteLine("Error on download to client " + clientIndex + 1);
                            }

                            var filePath = textBox2.Text + "(" + checkedListBox1.CheckedIndices[i] + 1 + ")\\winccom\\LOAD.LOG";
                            if (File.Exists(filePath))
                            {
                                System.IO.FileStream fs = new System.IO.FileStream(filePath, System.IO.FileMode.Open, System.IO.FileAccess.Read, System.IO.FileShare.ReadWrite);
                                System.IO.StreamReader sr = new System.IO.StreamReader(fs);
                                List<String> lst = new List<string>();

                                while (!sr.EndOfStream)
                                    lst.Add(sr.ReadLine());

                                if (downloadTargetWindowText.Where(x => x.Contains("Canceled:")).Count() > 0)
                                {
                                    logFile.WriteLine("Client " + clientIndex + " download canceled - RT station not obtainable");
                                    MessageBox.Show(new Form { TopMost = true }, " Client " + clientIndex + " download canceled - RT station not obtainable - will continue to next client download");
                                    continue;
                                }
                            }

                            SleepUntilDownloadFeedback(checkedListBox1.CheckedIndices[i] + 1);

                            //System.Threading.Thread.Sleep(Int32.Parse(textBox3.Text) * 1000); //wait for download to be done...
                            IntPtr dldingTgtHandle = FindWindow(tgtWndClass, "Downloading to target system");
                            if (dldingTgtHandle != IntPtr.Zero)
                            {
                                //Download to target system was completed successfully. do not send enter until this text is present in the window...
                                var dldingTgtText = ExtractWindowTextByHandle(dldingTgtHandle);

                                DateTime foundTime = DateTime.Now;
                                bool stillClosing = false;
                                do
                                {
                                    dldingTgtText = ExtractWindowTextByHandle(dldingTgtHandle);
                                    if (dldingTgtText.Where(x => x.Contains("Closing project on the Runtime OS.")).Count() > 0) //check if closing project takes too long...
                                    {
                                        int diffInSeconds = (DateTime.Now - foundTime).Seconds;
                                        if (stillClosing == false && diffInSeconds > 60)
                                        {
                                            stillClosing = true; //not used yet

                                            MessageBox.Show(new Form { TopMost = true }, "Please check the client " + clientIndex + ", it seems something is open and prevents project close.");
                                        }
                                    }
                                    System.Threading.Thread.Sleep(1000);
                                } while (dldingTgtText.Where(x => x.Contains("Download to target system was completed successfully")).Count() == 0);

                                System.Threading.Thread.Sleep(500);
                                SetForegroundWindow(dldingTgtHandle);
                                System.Threading.Thread.Sleep(300);
                                SendKeys.SendWait("{ENTER}");
                                SetForegroundWindow(ncmHandle);
                            }
                        }
                    }
                }
                logFile.WriteLine("Closing logfile at " + DateTime.Now);
                logFile.Close();
                MessageBox.Show(new Form { TopMost = true }, "The NCM download process has been finished!"); //careful to focus on it
            }
        }

        private void NavigateToIndex(int index)
        {
            for (int i = 0; i < index; i++)
            {
                SendKeys.Send("{DOWN}");
            }
        }

        private void ResetExpansions()
        {
            for (int i = 0; i < Int32.Parse(textBox4.Text) * 3; i++)
            {
                SendKeys.Send("{DOWN}");
                for (int j = 0; j < 6; j++)
                {
                    SendKeys.Send("{RIGHT}");
                }
            }
            for (int i = 0; i < Int32.Parse(textBox4.Text) * 3; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    SendKeys.Send("{LEFT}");
                }
                SendKeys.Send("{UP}");
            }
            SendKeys.Send("{RIGHT}");
            SendKeys.Send("{DOWN}");
        }

        private void DownloadToCurrentIndex(int index)
        {
            NavigateToIndex(index);
            SendKeys.Send("{RIGHT}");
            SendKeys.Send("{RIGHT}");
            SendKeys.Send("{RIGHT}");
            SendKeys.Send("{RIGHT}");
            SendKeys.Send("{RIGHT}");
            SendKeys.Send("{RIGHT}");
            SendKeys.Send("{RIGHT}");
            SendKeys.Send("^(l)");
        }

        private void ReturnToFirstClient()
        {
            for (int i = 0; i < 10; i++)
            {
                SendKeys.Send("{LEFT}");
            }
            SendKeys.Send("{RIGHT}");

            for (int i = 0; i < Int32.Parse(textBox1.Text); i++)
            {
                SendKeys.Send("{DOWN}");
            }
        }

        // Send a key to the button when the user double-clicks anywhere on the form.
        private void Form1_DoubleClick(object sender, EventArgs e)
        {
            // Send the enter key to the button, which raises the click
            // event for the button. This works because the tab stop of
            // the button is 0.
            SendKeys.Send("{ENTER}");
        }

        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(161, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Clients start index:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(259, 37);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(28, 20);
            this.textBox1.TabIndex = 1;
            this.textBox1.Text = "3";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // button1
            // 
            this.button1.AutoSize = true;
            this.button1.Location = new System.Drawing.Point(12, 212);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(275, 35);
            this.button1.TabIndex = 2;
            this.button1.Text = "Download to selected NCM Clients";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.BackColor = System.Drawing.SystemColors.Control;
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Location = new System.Drawing.Point(12, 37);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.ScrollAlwaysVisible = true;
            this.checkedListBox1.Size = new System.Drawing.Size(143, 169);
            this.checkedListBox1.TabIndex = 8;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(259, 66);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(28, 20);
            this.textBox4.TabIndex = 9;
            this.textBox4.Text = "4";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(164, 69);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Number of clients";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(12, 11);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(275, 20);
            this.textBox2.TabIndex = 11;
            this.textBox2.Text = "D:\\Project\\SDIB_TCM\\wincproj\\SDIB_TCM_CLT_Ref";
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(299, 262);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.checkedListBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "NCM Manager Automation";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            int numClients = Int32.Parse(textBox4.Text);
            checkedListBox1.Items.Clear();

            for (int i = 0; i < numClients; i++)
            {
                string cltName = "Client " + Convert.ToString(i + 1);
                checkedListBox1.Items.Add(cltName);
            }

            if (numClients > (int)checkedListBox1.Height / 15) checkedListBox1.ScrollAlwaysVisible = true;

            checkedListBox1.Update();
        }
    }
}