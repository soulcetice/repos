using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;

namespace SimulateKeyPress
{

  class Form1 : Form
  {
    private System.Windows.Forms.Button button1;
    private System.Windows.Forms.TextBox textBox1;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.TextBox textBox3;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.CheckedListBox checkedListBox1;
    private System.Windows.Forms.TextBox textBox4;
    private System.Windows.Forms.Label label5;
    private Form frm1 = new Form();

    [STAThread]
    public static void Main()
    {
      GetDate("7/15/2020 4:10:19 PM: Success: Download to target system was completed successfully.");

      Application.EnableVisualStyles();
      Application.Run(new Form1()
      {
        //Size = new Size(278, 500)
      }
      );
    }

    public static void GetDate(string str)
    {
      var strLine = str;
      var splitLine = strLine.Split(Convert.ToChar(" "));

      //zeros
      if (splitLine[0].StartsWith("0") == false) splitLine[0] = "0" + splitLine[0];
      splitLine[2] = splitLine[2].Replace(":", "");

      var stringTimestamp = splitLine[0] + " " + splitLine[1] + " " + splitLine[2];

      DateTime dateTime;
      string[] validformats = new[] { "MM/dd/yyyy", "MM/dd/yyyy h:mm:ss tt" };

      CultureInfo provider = CultureInfo.InvariantCulture;

      if (DateTime.TryParseExact(stringTimestamp, validformats, provider,
                                  DateTimeStyles.None, out dateTime))
      {
        Console.WriteLine("The specified date is valid: " + dateTime);
      }
      else
      {
        Console.WriteLine("Unable to parse the specified date");
      }
    }

    public Form1()
    {
      InitializeComponent();

      textBox4_TextChanged(textBox4, new System.EventArgs());

      button1.Click += new EventHandler(Button1_Click);


      this.DoubleClick += new EventHandler(Form1_DoubleClick);
      this.Controls.Add(button1);
      this.Controls.Add(textBox1);
    }

    // Get a handle to an application window.
    [DllImport("USER32.DLL", CharSet = CharSet.Unicode)]
    public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

    //get objects in window ?
    [DllImport("user32.dll")]
    public static extern IntPtr FindWindowEx(IntPtr handleParent, IntPtr handleChild, string className, string WindowName);

    // Activate an application window.
    [DllImport("USER32.DLL")]
    public static extern bool SetForegroundWindow(IntPtr hWnd);
    internal delegate int WindowEnumProc(IntPtr hwnd, IntPtr lparam);

    [DllImport("user32.dll")]
    static extern IntPtr SendMessage(IntPtr hWnd, int Msg, int wParam, IntPtr lParam);

    private const int BM_CLICK = 0x00F5;

    // Send a series of key presses to the Calculator application.
    private void Button1_Click(object sender, EventArgs e)
    {
      if (textBox1.Text == null || textBox1.Text == "")
      {
        MessageBox.Show("Please input the index at which clients start");
        return;
      }
      if (checkedListBox1.CheckedItems.Count == 0)
      {
        MessageBox.Show("You have not checked any clients to download to!");
        return;
      }

      List<System.IntPtr> childObjects = new List<System.IntPtr>();
      Process[] anotherApps = Process.GetProcessesByName("s7tgtopx");
      if (anotherApps.Length == 0) return;
      if (anotherApps[0] != null)
      {
        childObjects = new WindowHandleInfo(anotherApps[0].MainWindowHandle).GetAllChildHandles();
      }

      IntPtr ncmHandle = FindWindow("s7tgtopx", null);
      IntPtr hWndTargetWindow = FindWindow("#32770", null);

      if (ncmHandle == IntPtr.Zero)
      {
        MessageBox.Show("Simatic NCM Manager is not running.");
        return;
      }

      //handle the missing software package notification
      if (hWndTargetWindow == IntPtr.Zero)
      {
        Console.WriteLine("The missing software package notification did not appear");
        SetForegroundWindow(ncmHandle);
      }
      else
      {
        IntPtr ButtonHandle = FindWindowEx(hWndTargetWindow, IntPtr.Zero, "Button", null);

        if (ButtonHandle != new IntPtr(0x00000000))
        {
          SetForegroundWindow(hWndTargetWindow);
          SendMessage(ButtonHandle, BM_CLICK, (int)IntPtr.Zero, IntPtr.Zero);
          SetForegroundWindow(ncmHandle);
        }
      }

      if (hWndTargetWindow != IntPtr.Zero)
      {
        // sys tree view 32 already selected when focusing - navigate from here
        SetForegroundWindow(ncmHandle);

        ReturnToFirstClient();

        //now perform actions from now on, i.e. CTRL+L
        for (int i = 0; i < checkedListBox1.CheckedItems.Count; i++)
        {

          //download process starts here - first needs to navigate to correct index
          DownloadToCurrentIndex(checkedListBox1.CheckedIndices[i]);

          //now new window with download os
          IntPtr OsDownloadTargetWindow = FindWindow("#32770", "Download OS");
          if (OsDownloadTargetWindow != IntPtr.Zero)
          {
            IntPtr DlButtonHandle = FindWindowEx(OsDownloadTargetWindow, IntPtr.Zero, "Button", null);
            if (DlButtonHandle != new IntPtr(0x00000000))
            {
              System.Threading.Thread.Sleep(500);
              SendKeys.SendWait("{ENTER}");
              System.Threading.Thread.Sleep(500);

              SetForegroundWindow(OsDownloadTargetWindow);
              SendKeys.Send("{ENTER}");

              //now we wait for download somehow
              //7/15/2020 4:10:19 PM: Success: Download to target system was completed successfully.


              System.Threading.Thread.Sleep(Int32.Parse(textBox3.Text) * 1000); //wait for download to be done...
              IntPtr DownloadSuccessfulWindow = FindWindow("#32770", null);
              if (DownloadSuccessfulWindow != IntPtr.Zero)
              {
                SetForegroundWindow(DownloadSuccessfulWindow);
                SendKeys.SendWait("{ENTER}");
                SetForegroundWindow(ncmHandle);
              }
            }
          }

        }

        MessageBox.Show("The NCM download process has been finished!");
      }
    }

    private void NavigateToIndex(int index)
    {
      ReturnToFirstClient();
      for (int i = 0; i < index; i++)
      {
        SendKeys.Send("{DOWN}");
      }
    }

    private void DownloadToCurrentIndex(int index)
    {
      NavigateToIndex(index);
      SendKeys.Send("{RIGHT}");
      SendKeys.Send("{DOWN}");
      SendKeys.Send("{RIGHT}");
      SendKeys.Send("{DOWN}");
      SendKeys.Send("^(l)");
    }

    private void ReturnToFirstClient()
    {
      for (int i = 0; i < 10; i++)
      {
        SendKeys.Send("{LEFT}");
      }
      SendKeys.Send("{RIGHT}");

      for (int i = 0; i < Int32.Parse(textBox1.Text); i++)
      {
        SendKeys.Send("{DOWN}");
      }
    }

    // Send a key to the button when the user double-clicks anywhere on the form.
    private void Form1_DoubleClick(object sender, EventArgs e)
    {
      // Send the enter key to the button, which raises the click
      // event for the button. This works because the tab stop of
      // the button is 0.
      SendKeys.Send("{ENTER}");
    }

    private void InitializeComponent()
    {
      this.label1 = new System.Windows.Forms.Label();
      this.textBox1 = new System.Windows.Forms.TextBox();
      this.button1 = new System.Windows.Forms.Button();
      this.textBox3 = new System.Windows.Forms.TextBox();
      this.label3 = new System.Windows.Forms.Label();
      this.label4 = new System.Windows.Forms.Label();
      this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
      this.textBox4 = new System.Windows.Forms.TextBox();
      this.label5 = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(23, 40);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(104, 13);
      this.label1.TabIndex = 0;
      this.label1.Text = "Clients start at index:";
      // 
      // textBox1
      // 
      this.textBox1.Location = new System.Drawing.Point(136, 37);
      this.textBox1.Name = "textBox1";
      this.textBox1.Size = new System.Drawing.Size(28, 20);
      this.textBox1.TabIndex = 1;
      this.textBox1.Text = "3";
      // 
      // button1
      // 
      this.button1.AutoSize = true;
      this.button1.Location = new System.Drawing.Point(12, 293);
      this.button1.Name = "button1";
      this.button1.Size = new System.Drawing.Size(275, 35);
      this.button1.TabIndex = 2;
      this.button1.Text = "Click to automate NCM manager";
      this.button1.UseVisualStyleBackColor = true;
      // 
      // textBox3
      // 
      this.textBox3.Location = new System.Drawing.Point(136, 12);
      this.textBox3.Name = "textBox3";
      this.textBox3.Size = new System.Drawing.Size(28, 20);
      this.textBox3.TabIndex = 5;
      this.textBox3.Text = "110";
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Location = new System.Drawing.Point(170, 15);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(18, 13);
      this.label3.TabIndex = 6;
      this.label3.Text = "[s]";
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.Location = new System.Drawing.Point(9, 15);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(118, 13);
      this.label4.TabIndex = 7;
      this.label4.Text = "Safe wait for download:";
      // 
      // checkedListBox1
      // 
      this.checkedListBox1.BackColor = System.Drawing.SystemColors.Control;
      this.checkedListBox1.FormattingEnabled = true;
      this.checkedListBox1.Location = new System.Drawing.Point(12, 102);
      this.checkedListBox1.Name = "checkedListBox1";
      this.checkedListBox1.ScrollAlwaysVisible = true;
      this.checkedListBox1.Size = new System.Drawing.Size(275, 169);
      this.checkedListBox1.TabIndex = 8;
      // 
      // textBox4
      // 
      this.textBox4.Location = new System.Drawing.Point(136, 63);
      this.textBox4.Name = "textBox4";
      this.textBox4.Size = new System.Drawing.Size(28, 20);
      this.textBox4.TabIndex = 9;
      this.textBox4.Text = "10";
      this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
      // 
      // label5
      // 
      this.label5.AutoSize = true;
      this.label5.Location = new System.Drawing.Point(38, 66);
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size(89, 13);
      this.label5.TabIndex = 10;
      this.label5.Text = "Number of clients";
      // 
      // Form1
      // 
      this.ClientSize = new System.Drawing.Size(299, 340);
      this.Controls.Add(this.label5);
      this.Controls.Add(this.textBox4);
      this.Controls.Add(this.checkedListBox1);
      this.Controls.Add(this.label4);
      this.Controls.Add(this.label3);
      this.Controls.Add(this.textBox3);
      this.Controls.Add(this.button1);
      this.Controls.Add(this.textBox1);
      this.Controls.Add(this.label1);
      this.Name = "Form1";
      this.Text = "NCM Manager App";
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    private void textBox4_TextChanged(object sender, EventArgs e)
    {
      int numClients = Int32.Parse(textBox4.Text);
      checkedListBox1.Items.Clear();
      for (int i = 0; i < numClients; i++)
      {
        string cltName = "Client " + Convert.ToString(i + 1);
        checkedListBox1.Items.Add(cltName);
      }

      if (numClients > (int)checkedListBox1.Height / 15) checkedListBox1.ScrollAlwaysVisible = true;

      checkedListBox1.Update();
    }
  }

  public class WindowHandleInfo
  {
    private delegate bool EnumWindowProc(IntPtr hwnd, IntPtr lParam);

    [DllImport("user32")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool EnumChildWindows(IntPtr window, EnumWindowProc callback, IntPtr lParam);

    private IntPtr _MainHandle;

    public WindowHandleInfo(IntPtr handle)
    {
      this._MainHandle = handle;
    }

    public List<IntPtr> GetAllChildHandles()
    {
      List<IntPtr> childHandles = new List<IntPtr>();

      GCHandle gcChildhandlesList = GCHandle.Alloc(childHandles);
      IntPtr pointerChildHandlesList = GCHandle.ToIntPtr(gcChildhandlesList);

      try
      {
        EnumWindowProc childProc = new EnumWindowProc(EnumWindow);
        EnumChildWindows(this._MainHandle, childProc, pointerChildHandlesList);
      }
      finally
      {
        gcChildhandlesList.Free();
      }

      return childHandles;
    }

    private bool EnumWindow(IntPtr hWnd, IntPtr lParam)
    {
      GCHandle gcChildhandlesList = GCHandle.FromIntPtr(lParam);

      if (gcChildhandlesList == null || gcChildhandlesList.Target == null)
      {
        return false;
      }

      List<IntPtr> childHandles = gcChildhandlesList.Target as List<IntPtr>;
      childHandles.Add(hWnd);

      return true;
    }
  }
}