using System;
using System.Runtime.InteropServices;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Windows.Shell;
using System.Diagnostics;
using System.Linq;
using System.Drawing.Printing;
using System.Windows.Forms.VisualStyles;

namespace SimulateKeyPress
{

    class Form1 : Form
    {
        private Button button1 = new Button();
        private Form frm1 = new Form();

        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.Run(new Form1()
            {
                Size = new Size(278, 500)
            }
            );
        }

        public Form1()
        {
            button1.Location = new Point(12, 12);
            button1.Width = 238;
            button1.Height = 25;
            button1.Margin = new Padding(3, 3, 3, 3);
            button1.TabIndex = 0;
            button1.Text = "Click to automate NCM manager";
            button1.AutoSize = true;
            button1.Click += new EventHandler(Button1_Click);

            this.DoubleClick += new EventHandler(Form1_DoubleClick);
            this.Controls.Add(button1);
        }

        // Get a handle to an application window.
        [DllImport("USER32.DLL", CharSet = CharSet.Unicode)]
        public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        //get objects in window ?
        [DllImport("user32.dll")]
        public static extern IntPtr FindWindowEx(IntPtr handleParent, IntPtr handleChild, string className, string WindowName);

        // Activate an application window.
        [DllImport("USER32.DLL")]
        public static extern bool SetForegroundWindow(IntPtr hWnd);
        internal delegate int WindowEnumProc(IntPtr hwnd, IntPtr lparam);

        [DllImport("user32.dll")]
        internal static extern bool EnumChildWindows(IntPtr hwnd, WindowEnumProc func, IntPtr lParam);

        [DllImport("user32.dll")]
        static extern IntPtr GetDlgItem(IntPtr hWnd, int nIDDlgItem);
        [DllImport("user32.dll")]
        static extern IntPtr SendMessage(IntPtr hWnd, int Msg, int wParam, IntPtr lParam);
        private const int BM_CLICK = 0x00F5;

        // Send a series of key presses to the Calculator application.
        private void Button1_Click(object sender, EventArgs e)
        {

            //foreach (Process proc in Process.GetProcesses())
            //{
            //    if (proc.MainWindowTitle.StartsWith("SIMATIC NCM Manager"))
            //    {
            //        //IntPtr handle = proc.MainWindowHandle;
            //        IntPtr p = proc.MainWindowHandle;

            //        // Verify that Calculator is a running process.
            //        if (p == IntPtr.Zero)
            //        {
            //            MessageBox.Show("Simatic NCM Manager is not running.");
            //            return;
            //        }

            //        // Make Calculator the foreground application and send it a set of calculations.
            //        SetForegroundWindow(p);

            //    }
            //}

            List<System.IntPtr> childObjects = new List<System.IntPtr>();
            Process[] anotherApps = Process.GetProcessesByName("s7tgtopx");
            if (anotherApps.Length == 0) return;
            if (anotherApps[0] != null)
            {
                childObjects = new WindowHandleInfo(anotherApps[0].MainWindowHandle).GetAllChildHandles();
            }

            IntPtr ncmHandle = FindWindow("s7tgtopx", null);
            IntPtr hWndTargetWindow = FindWindow("#32770", null);
            IntPtr tree = new IntPtr(00070820);

            if (ncmHandle == IntPtr.Zero)
            {
                MessageBox.Show("Simatic NCM Manager is not running.");
                return;
            }

            //handle the missing software package notification
            if (hWndTargetWindow == IntPtr.Zero)
            {
                Console.WriteLine("The missing software package notification did not appear");
                SetForegroundWindow(ncmHandle);
            }
            else
            {
                IntPtr ButtonHandle = FindWindowEx(hWndTargetWindow, IntPtr.Zero, "Button", null);

                if (ButtonHandle != new IntPtr(0x00000000))
                {
                    SetForegroundWindow(hWndTargetWindow);
                    SendMessage(ButtonHandle, BM_CLICK, (int)IntPtr.Zero, IntPtr.Zero);
                    SetForegroundWindow(ncmHandle);
                }
            }

            if (hWndTargetWindow != IntPtr.Zero)
            {
                SetForegroundWindow(ncmHandle);
            }
        }

        // Send a key to the button when the user double-clicks anywhere on the form.
        private void Form1_DoubleClick(object sender, EventArgs e)
        {
            // Send the enter key to the button, which raises the click
            // event for the button. This works because the tab stop of
            // the button is 0.
            SendKeys.Send("{ENTER}");
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(262, 203);
            this.Name = "Form1";
            this.ResumeLayout(false);

        }
    }

    public class WindowHandleInfo
    {
        private delegate bool EnumWindowProc(IntPtr hwnd, IntPtr lParam);

        [DllImport("user32")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool EnumChildWindows(IntPtr window, EnumWindowProc callback, IntPtr lParam);

        private IntPtr _MainHandle;

        public WindowHandleInfo(IntPtr handle)
        {
            this._MainHandle = handle;
        }

        public List<IntPtr> GetAllChildHandles()
        {
            List<IntPtr> childHandles = new List<IntPtr>();

            GCHandle gcChildhandlesList = GCHandle.Alloc(childHandles);
            IntPtr pointerChildHandlesList = GCHandle.ToIntPtr(gcChildhandlesList);

            try
            {
                EnumWindowProc childProc = new EnumWindowProc(EnumWindow);
                EnumChildWindows(this._MainHandle, childProc, pointerChildHandlesList);
            }
            finally
            {
                gcChildhandlesList.Free();
            }

            return childHandles;
        }

        private bool EnumWindow(IntPtr hWnd, IntPtr lParam)
        {
            GCHandle gcChildhandlesList = GCHandle.FromIntPtr(lParam);

            if (gcChildhandlesList == null || gcChildhandlesList.Target == null)
            {
                return false;
            }

            List<IntPtr> childHandles = gcChildhandlesList.Target as List<IntPtr>;
            childHandles.Add(hWnd);

            return true;
        }
    }
}