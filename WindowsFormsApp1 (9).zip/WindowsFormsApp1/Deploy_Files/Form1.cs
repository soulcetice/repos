﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Deploy_Files
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            textBox5_TextChanged(textBox5, new System.EventArgs());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            dateTimePicker1.Value = dateTimePicker2.Value.AddHours(Convert.ToDouble(textBox5.Text));
        }

        public List<dynamic> myFiles = new List<dynamic>();

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            myFiles.AddRange(openFileDialog1.FileNames);
            Console.WriteLine("nice");
        }
    }
}
