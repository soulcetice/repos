using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;

namespace SimulateKeyPress
{

    class Form1 : Form
    {
        private Button button1;
        private TextBox textBox1;
        private Label label1;
        private CheckedListBox checkedListBox1;
        private TextBox textBox4;
        private Label label5;
        private TextBox textBox2;
        private Form frm1 = new Form();

        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.Run(new Form1());
            //Done by Muresan Radu-Adrian MURA02 20200716
        }

        public Form1()
        {
            InitializeComponent();

            string configPath = Application.ExecutablePath + ".confiig";
            if (File.Exists(configPath))
            {
                var configFile = File.ReadLines(configPath);

                textBox2.Text = configFile.ElementAt(0);
                textBox1.Text = configFile.ElementAt(1);
                textBox4.Text = configFile.ElementAt(2);
            }

            textBox4_TextChanged(textBox4, new System.EventArgs());

            button1.Click += new EventHandler(Button1_Click);

            this.DoubleClick += new EventHandler(Form1_DoubleClick);
            this.Controls.Add(button1);
            this.Controls.Add(textBox1);
        }

        // Get a handle to an application window.
        [DllImport("USER32.DLL", CharSet = CharSet.Unicode)]
        public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        //get objects in window ?
        [DllImport("user32.dll")]
        public static extern IntPtr FindWindowEx(IntPtr handleParent, IntPtr handleChild, string className, string WindowName);

        // Activate an application window.
        [DllImport("USER32.DLL")]
        public static extern bool SetForegroundWindow(IntPtr hWnd);
        internal delegate int WindowEnumProc(IntPtr hwnd, IntPtr lparam);

        [DllImport("user32.dll")]
        static extern IntPtr SendMessage(IntPtr hWnd, int Msg, int wParam, IntPtr lParam);

        private const int BM_CLICK = 0x00F5;

        [System.Runtime.InteropServices.DllImport("user32.dll", EntryPoint = "SendMessage", CharSet = System.Runtime.InteropServices.CharSet.Auto)]
        public static extern bool SendMessage(IntPtr hWnd, uint Msg, int wParam, StringBuilder lParam);

        [System.Runtime.InteropServices.DllImport("user32.dll", SetLastError = true)]
        public static extern IntPtr SendMessage(int hWnd, int Msg, int wparam, int lparam);

        const int WM_GETTEXT = 0x000D;
        const int WM_GETTEXTLENGTH = 0x000E;

        public string GetControlText(IntPtr hWnd)
        {

            // Get the size of the string required to hold the window title (including trailing null.) 
            Int32 titleSize = SendMessage((int)hWnd, WM_GETTEXTLENGTH, 0, 0).ToInt32();

            // If titleSize is 0, there is no title so return an empty string (or null)
            if (titleSize == 0)
                return String.Empty;

            StringBuilder title = new StringBuilder(titleSize + 1);

            SendMessage(hWnd, (int)WM_GETTEXT, title.Capacity, title);

            return title.ToString();
        }

        public List<string> ExtractWindowTextByHandle(IntPtr handle)
        {
            List<System.IntPtr> childObjects = new List<System.IntPtr>();
            var extractedText = new List<string>();
            childObjects = new WindowHandleInfo(handle).GetAllChildHandles();
            for (int i = 0; i < childObjects.Count; i++)
            {
                extractedText.Add(GetControlText(childObjects[i]));
            }
            return extractedText;
        }

        private void SleepUntilDownloadFeedback(int clientIndex)
        {
            bool finished = false;
            bool copied = false;
            DateTime copiedTime = DateTime.Now;
            DateTime comparTime = copiedTime;

            var filePath = textBox2.Text + "(" + clientIndex + ")\\winccom\\LOAD.LOG";

            System.Threading.Thread.Sleep(20000);

            while (finished == false)
            {
                var lastLine = File.ReadLines(filePath).Last();

                finished = lastLine.Contains("The lock on the project was removed"); //now can click ok to conclude download and onto next

                //safety wait for 40 seconds after the files have been copied, then check is finished...
                if (lastLine.Contains("The files were copied successfully") && copiedTime == comparTime)
                {
                    copied = true;
                    copiedTime = DateTime.Now;
                }
                if (lastLine.Contains("The computer name was changed in the project") && copied == true)
                {
                    int diffInSeconds = (DateTime.Now - copiedTime).Seconds;
                    if (finished == false && diffInSeconds > 40)
                    {
                        finished = true;
                    }
                }

                System.Threading.Thread.Sleep(500);
            }
        }

        public List<string> ExtractTextByProcessName(string handle)
        {
            List<System.IntPtr> childObjects = new List<System.IntPtr>();
            var extractedText = new List<string>();
            Process[] anotherApps = Process.GetProcessesByName("s7tgtopx");
            if (anotherApps.Length > 0)
            {
                if (anotherApps[0] != null)
                {
                    childObjects = new WindowHandleInfo(anotherApps[0].MainWindowHandle).GetAllChildHandles();
                    for (int i = 0; i < childObjects.Count; i++)
                    {
                        extractedText.Add(GetControlText(childObjects[i]));
                    }
                }
            }
            return extractedText;
        }

        // Send a series of key presses to the application.
        private void Button1_Click(object sender, EventArgs e)
        {


            if (textBox1.Text == null || textBox1.Text == "")
            {
                MessageBox.Show("Please input the index at which clients start");
                return;
            }
            if (textBox2.Text == null || textBox2.Text == "")
            {
                MessageBox.Show("Please input the path in the following form: " + @"D:\Project\SDIB_TCM\wincproj\SDIB_TCM_CLT_Ref");
                return;
            }
            if (textBox4.Text == null || textBox4.Text == "")
            {
                MessageBox.Show("Please input the number of clients");
                return;
            }

            //write config file
            string configPath = Application.ExecutablePath + ".confiig";
            var configFile = File.CreateText(configPath);
            configFile.WriteLine(textBox2.Text);
            configFile.WriteLine(textBox1.Text);
            configFile.WriteLine(textBox4.Text);
            configFile.Close();

            var logFile = File.CreateText(Application.StartupPath + "\\NCM_Downloader.txt");

            if (checkedListBox1.CheckedItems.Count == 0)
            {
                MessageBox.Show("You have not checked any clients to download to!");
                return;
            }

            IntPtr ncmHandle = FindWindow("s7tgtopx", null);
            IntPtr targetWindowHandle = FindWindow("#32770", null);

            if (ncmHandle == IntPtr.Zero)
            {
                MessageBox.Show("Simatic NCM Manager is not running.");
                return;
            }

            var extractedNCMText = new List<string>();
            extractedNCMText = ExtractWindowTextByHandle(targetWindowHandle);
            do
            {
                extractedNCMText = ExtractWindowTextByHandle(ncmHandle);
                System.Threading.Thread.Sleep(2000);
            } while (extractedNCMText.Where(x => x.Contains("Project")).Count() == 0);

            //handle the missing software package notification
            if (targetWindowHandle == IntPtr.Zero)
            {
                Console.WriteLine("The missing software package notification did not appear");
                SetForegroundWindow(ncmHandle);
                //ResetExpansions();
            }
            else
            {
                IntPtr ButtonHandle = FindWindowEx(targetWindowHandle, IntPtr.Zero, "Button", null);

                if (ButtonHandle != new IntPtr(0x00000000))
                {
                    SetForegroundWindow(targetWindowHandle);
                    SendMessage(ButtonHandle, BM_CLICK, (int)IntPtr.Zero, IntPtr.Zero);
                    SetForegroundWindow(ncmHandle);
                }
            }

            if (targetWindowHandle != IntPtr.Zero)
            {
                // sys tree view 32 already selected when focusing - navigate from here
                SetForegroundWindow(ncmHandle);

                ReturnToFirstClient();

                //now perform actions from now on, i.e. CTRL+L
                for (int i = 0; i < checkedListBox1.CheckedItems.Count; i++)
                {

                    //download process starts here - first needs to navigate to correct index
                    DownloadToCurrentIndex(checkedListBox1.CheckedIndices[i]);

                    //now new window with download os
                    IntPtr OsDownloadTargetWindow = FindWindow("#32770", "Download OS");
                    if (OsDownloadTargetWindow != IntPtr.Zero)
                    {
                        IntPtr DlButtonHandle = FindWindowEx(OsDownloadTargetWindow, IntPtr.Zero, "Button", null);
                        if (DlButtonHandle != new IntPtr(0x00000000))
                        {
                            System.Threading.Thread.Sleep(500); //important to wait a bit
                            SendKeys.SendWait("{ENTER}"); //close runtime? focus is on yes
                            System.Threading.Thread.Sleep(500);

                            SetForegroundWindow(OsDownloadTargetWindow);
                            SendKeys.Send("{ENTER}");

                            ////now we wait for download somehow
                            ////7/15/2020 4:10:19 PM: Success: Download to target system was completed successfully.
                            SleepUntilDownloadFeedback(checkedListBox1.CheckedIndices[i] + 1);
                            //System.Threading.Thread.Sleep(2000); //wait for download to be done...

                            //System.Threading.Thread.Sleep(Int32.Parse(textBox3.Text) * 1000); //wait for download to be done...
                            IntPtr downloadSuccessfulHandle = FindWindow("#32770", "Downloading to target system");
                            if (downloadSuccessfulHandle != IntPtr.Zero)
                            {
                                //Loaded
                                //Download to target system was completed successfully.
                                //do not send enter until this text is present in the window...
                                var extractedDownloadText = ExtractWindowTextByHandle(downloadSuccessfulHandle);
                                do
                                {
                                    extractedDownloadText = ExtractWindowTextByHandle(downloadSuccessfulHandle);
                                    System.Threading.Thread.Sleep(2000);
                                } while (extractedDownloadText.Where(x => x.Contains("Download to target system was completed successfully")).Count() == 0);

                                var newList = "";
                                foreach (var item in extractedDownloadText)
                                {
                                    logFile.WriteLine(item);
                                    newList = newList + " " + item;
                                }

                                MessageBox.Show(newList);

                                System.Threading.Thread.Sleep(500);
                                SetForegroundWindow(downloadSuccessfulHandle);
                                System.Threading.Thread.Sleep(500);
                                SendKeys.SendWait("{ENTER}");
                                SetForegroundWindow(ncmHandle);
                            }
                        }
                    }
                }
                logFile.Close();
                MessageBox.Show("The NCM download process has been finished!");
            }
        }

        private void NavigateToIndex(int index)
        {
            ReturnToFirstClient();
            for (int i = 0; i < index; i++)
            {
                SendKeys.Send("{DOWN}");
            }
        }

        private void ResetExpansions()
        {
            for (int i = 0; i < Int32.Parse(textBox1.Text) * 3; i++)
            {
                SendKeys.Send("{DOWN}");
                for (int j = 0; j < 6; j++)
                {
                    SendKeys.Send("{RIGHT}");
                }
            }
            for (int i = 0; i < Int32.Parse(textBox1.Text) * 3; i++)
            {
                for (int j = 0; j < 6; j++)
                {
                    SendKeys.Send("{LEFT}");
                }
                SendKeys.Send("{UP}");
            }
        }

        private void DownloadToCurrentIndex(int index)
        {
            NavigateToIndex(index);
            SendKeys.Send("{RIGHT}");
            SendKeys.Send("{RIGHT}");
            SendKeys.Send("{RIGHT}");
            SendKeys.Send("{RIGHT}");
            SendKeys.Send("{RIGHT}");
            SendKeys.Send("{RIGHT}");
            SendKeys.Send("^(l)");
        }

        private void ReturnToFirstClient()
        {
            for (int i = 0; i < 10; i++)
            {
                SendKeys.Send("{LEFT}");
            }
            SendKeys.Send("{RIGHT}");

            for (int i = 0; i < Int32.Parse(textBox1.Text); i++)
            {
                SendKeys.Send("{DOWN}");
            }
        }

        // Send a key to the button when the user double-clicks anywhere on the form.
        private void Form1_DoubleClick(object sender, EventArgs e)
        {
            // Send the enter key to the button, which raises the click
            // event for the button. This works because the tab stop of
            // the button is 0.
            SendKeys.Send("{ENTER}");
        }

        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(161, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Clients start index:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(259, 37);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(28, 20);
            this.textBox1.TabIndex = 1;
            this.textBox1.Text = "3";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // button1
            // 
            this.button1.AutoSize = true;
            this.button1.Location = new System.Drawing.Point(12, 212);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(275, 35);
            this.button1.TabIndex = 2;
            this.button1.Text = "Download to selected NCM Clients";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.BackColor = System.Drawing.SystemColors.Control;
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Location = new System.Drawing.Point(12, 37);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.ScrollAlwaysVisible = true;
            this.checkedListBox1.Size = new System.Drawing.Size(143, 169);
            this.checkedListBox1.TabIndex = 8;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(259, 66);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(28, 20);
            this.textBox4.TabIndex = 9;
            this.textBox4.Text = "4";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(164, 69);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Number of clients";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(12, 11);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(275, 20);
            this.textBox2.TabIndex = 11;
            this.textBox2.Text = "D:\\Project\\SDIB_TCM\\wincproj\\SDIB_TCM_CLT_Ref";
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(299, 262);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.checkedListBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "NCM Manager Automation";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            int numClients = Int32.Parse(textBox4.Text);
            checkedListBox1.Items.Clear();

            for (int i = 0; i < numClients; i++)
            {
                string cltName = "Client " + Convert.ToString(i + 1);
                checkedListBox1.Items.Add(cltName);
            }

            if (numClients > (int)checkedListBox1.Height / 15) checkedListBox1.ScrollAlwaysVisible = true;

            checkedListBox1.Update();
        }
    }

    public class WindowHandleInfo
    {
        private delegate bool EnumWindowProc(IntPtr hwnd, IntPtr lParam);

        [DllImport("user32")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool EnumChildWindows(IntPtr window, EnumWindowProc callback, IntPtr lParam);

        private IntPtr _MainHandle;

        public WindowHandleInfo(IntPtr handle)
        {
            this._MainHandle = handle;
        }

        public List<IntPtr> GetAllChildHandles()
        {
            List<IntPtr> childHandles = new List<IntPtr>();

            GCHandle gcChildhandlesList = GCHandle.Alloc(childHandles);
            IntPtr pointerChildHandlesList = GCHandle.ToIntPtr(gcChildhandlesList);

            try
            {
                EnumWindowProc childProc = new EnumWindowProc(EnumWindow);
                EnumChildWindows(this._MainHandle, childProc, pointerChildHandlesList);
            }
            finally
            {
                gcChildhandlesList.Free();
            }

            return childHandles;
        }

        private bool EnumWindow(IntPtr hWnd, IntPtr lParam)
        {
            GCHandle gcChildhandlesList = GCHandle.FromIntPtr(lParam);

            if (gcChildhandlesList == null || gcChildhandlesList.Target == null)
            {
                return false;
            }

            List<IntPtr> childHandles = gcChildhandlesList.Target as List<IntPtr>;
            childHandles.Add(hWnd);

            return true;
        }
    }
}